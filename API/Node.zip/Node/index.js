const express = require("express");
const server = express();
const database = require("./Database");
const port = 3000;
server.set("view-engine", "ejs");

server.get("/", function (request, response) {
    let users = database.getUsers();
    response.render("index.ejs", { users });
});

function setAdd() {
    server.get("/add", function(request, response) {
        if (!request.url.includes("?")) {
            response.render("addUser.ejs");
        } else {
            let name = request.query.name;
            let lastname = request.query.lastname;
            let email = request.query.email;
            database.addUser(name, lastname, email);
            response.redirect("/");
        }
    });
    
}
setAdd();

server.get("/remove", function(request, response) {
    if (!request.url.includes("?")) {
        response.render("deleteUser.ejs");
    } else {
        let id = request.query.id;
        database.removeUser(id);
        console.log(database.getUsers());
        response.redirect("/");
    }
});

server.get("/edit", function(request, response) {
    if (!request.url.includes("?")) {
        response.render("editUser.ejs");
    } else {
        let name = request.query.name;
        let lastN = request.query.lastname;
        let correo = request.query.email;
        let id = request.query.id;
        database.editUser(name, lastN, correo, id);
        response.redirect("/");
    }
});


server.listen(port, function() {
    console.log("Running at ", port);
});