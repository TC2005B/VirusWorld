const { json } = require("express");
const fs = require("fs");
let resultado = [];

var mysql = require('mysql')
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'EdgaRostro22',
    database: 'API'
})

connection.connect();

function getUsers() {
    connection.query('SELECT * FROM `users`', function (err, results, fields) {
        if (err) {
            throw err
        }
        else {
            resultado = results;   
        }
    })
    return resultado;
}

function containsUser(name) {
    users = getUsers();
    for (let i = 0; i < users.length; ++i) {
        if (users[i].name == name) return true;

    }
    return false;
}

function addUser(name, lastname, email) {
    if (containsUser(name)) return false;

    connection.query('INSERT INTO users SET ?', {Nombre: name, Apellido: lastname, Correo: email}, function (err, rows, fields) {
        if (err) throw err
    })
}

function removeUser(id) {
    connection.query('DELETE FROM users WHERE idUser = ?', id, function (err, results, fields) {
        if (err) {
            throw err
        }
        else {
            console.log("Se elimino");
        }
    })
}

function editUser(newName, newLastN, newEmail, id) {
    connection.query('UPDATE users SET Nombre = ?, Apellido = ?, Correo = ? WHERE idUser = ?', [newName, newLastN, newEmail, id], function (err, results, fields) {
        if (err) {
            throw err
        }
        else {
            console.log("Se Modifico");
        }
    })
}

module.exports = { addUser, getUsers, removeUser, editUser };
